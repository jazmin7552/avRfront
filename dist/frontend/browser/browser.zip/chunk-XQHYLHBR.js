var a={production:!1,apiUrl:"http://restauranteav-env.eba-yavju4ap.us-east-2.elasticbeanstalk.com/api"};export{a};
